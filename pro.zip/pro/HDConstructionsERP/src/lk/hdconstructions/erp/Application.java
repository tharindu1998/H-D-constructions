package lk.hdconstructions.erp;

import lk.hdconstructions.erp.views.login.Login;

public class Application {

	public static void main(String[] args) {
            
		
		Login login = new Login();
		login.setVisible(true);
		
	}
}
