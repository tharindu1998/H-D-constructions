package lk.hdconstructions.erp.utils.constants;


/**
 *
 * @author Malith Bandara
 */
public class DBConstants {
	
	public static final String DB_USERNAME = "root";
	public static final String DB_PASSWORD = "pass123$";
	public static final String DB_URL = "jdbc:sqlserver://hdconstructions.chtqaw4m5zbd.us-east-1.rds.amazonaws.com;databaseName=erp";
}
